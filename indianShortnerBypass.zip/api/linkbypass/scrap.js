import { stepZero, stepOne, stepTwo, stepThree, stepSix, stepSeven } from "../../backbone/page";

export default async function handler(req, res) {

    // ----------------------------------------------------------------------------------------
    // Step 0: Submit the form
    // ----------------------------------------------------------------------------------------
    const url = `https://indianshortner.in/fm4v6eDb`

    const { responseToSend, errorToSend } = await stepZero(url);

    if (errorToSend && errorToSend.length > 0) {
        return res.status(500).json({ errors: errorToSend });
    }

    const formZero = responseToSend[0].formData[0]

    console.log(formZero)

    // ----------------------------------------------------------------------------------------
    // Step 1: Submit the form
    // ----------------------------------------------------------------------------------------

    const { responseToSendOne, errorToSendOne } = await stepOne(formZero.action, formZero.method, formZero.inputs.go)

    if (errorToSendOne && errorToSendOne.length > 0) {
        return res.status(500).json({ errors: errorToSendOne });
    }

    const formTwo = responseToSendOne[0].formData[0]
    console.log(formTwo)

    // ----------------------------------------------------------------------------------------
    // Step 2: Submit the form
    // ----------------------------------------------------------------------------------------


    const { responseToSendTwo, errorToSendTwo } = await stepTwo(formTwo.action, formTwo.method, formTwo.inputs)

    if (errorToSendTwo && errorToSendTwo.length > 0) {
        return res.status(500).json({ errors: errorToSendTwo });
    }

    // ----------------------------------------------------------------------------------------
    // Step 3: Submit the form
    // ----------------------------------------------------------------------------------------

    const { responseToSendThree, errorToSendThree } = await stepThree(responseToSendTwo[0].link);

    if (errorToSendThree && errorToSendThree.length > 0) {
        return res.status(500).json({ errors: errorToSendThree });
    }

    const formFour = responseToSendThree[0].formData[0]

    console.log(responseToSendThree)

    const dataStepFour = await stepOne(formFour.action, formFour.method, formFour.inputs.go)

    const formFive = dataStepFour.responseToSendOne[0].formData[0]
    console.log(`formFive : ${JSON.stringify(formFive)}`)

    const dataStepFive = await stepTwo(formFive.action, formFive.method, formFive.inputs)
    const setpSixUrl = dataStepFive.responseToSendTwo[0].link


    const dataStep = await stepSix(setpSixUrl)


    const raw = dataStep.responseToSendThree[0].formData[0].inputs

    const cookies = dataStep.responseToSendThree[1]
    const appSession = cookies[0].split(`AppSession=`)[1].split(';')[0]
    const csrfToken = cookies[1].split(`csrfToken=`)[1].split(';')[0]
    const app_visitor = cookies[2].split(`app_visitor=`)[1].split(';')[0]

    const method = raw._method
    const rawCsrfToken = raw._csrfToken
    const ad_form_data = raw.ad_form_data
    const tokenField = raw["_Token[fields]"]
    const tokenUnlock = raw["_Token[unlocked]"]

    console.log(`dataStep : ${JSON.stringify(dataStep)}`)

    console.log(`--------------------------------------------------------------\n}`)
    console.log(`raw_cookie : ${JSON.stringify(raw)}, ${csrfToken}, ${appSession}, ${app_visitor}`)
    console.log(`--------------------------------------------------------------\n}`)

    const stageLast = await stepSeven(url, method, rawCsrfToken, ad_form_data, tokenField, tokenUnlock, csrfToken, appSession, app_visitor)

    console.log(`setpSixUrl : ${setpSixUrl}`)
    res.status(200).json({ data: stageLast, cookies, raw });
}
