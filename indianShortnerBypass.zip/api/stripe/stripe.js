// pages/api/check-credit-cards.js

import Stripe from 'stripe';
import fs from 'fs';
import path from 'path';

const stripe = new Stripe('sk_live_5MagleOb5fGSB5PB329tGggO00atK5bXZk');

// define function to check credit card
async function checkCC(cc) {
    try {
        // create a token using the credit card details
        const token = await stripe.tokens.create({
            card: {
                number: cc.number,
                exp_month: cc.exp_month,
                exp_year: cc.exp_year,
                cvc: cc.cvc,
            },
        });

        // create a charge using the token
        const charge = await stripe.charges.create({
            amount: 1000, // charge $10.00 (USD)
            currency: 'usd',
            source: token.id,
            description: 'Test Charge',
        });

        // return success response
        return { status: 'success', response: charge };
    } catch (error) {
        if (error.type === 'StripeRateLimitError') {
            // if rate limit error, retry request after 1 second
            await new Promise(resolve => setTimeout(resolve, 1000));
            return checkCC(cc);
        } else if (error.type === 'StripeCardError') {
            return { status: 'card_error', response: error };
        } else if (error.type === 'StripeInvalidRequestError') {
            return { status: 'invalid_request_error', response: error };
        } else if (error.type === 'StripeAuthenticationError') {
            return { status: 'authentication_error', response: error };
        } else if (error.type === 'StripeAPIError') {
            return { status: 'api_connection_error', response: error };
        } else {
            return { status: 'stripe_error', response: error };
        }
    }
}

export default async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ message: 'Method Not Allowed' });
    }

    try {
        // read credit card details from file
        const filePath = path.join(process.cwd(), 'cc.txt');
        const ccList = fs.readFileSync(filePath, 'utf8').split('\n').map(line => line.trim());

        const results = [];

        for (const ccStr of ccList) {
            // split the credit card details into components
            const [number, exp_month, exp_year, cvc] = ccStr.split('|');
            const ccDict = { number, exp_month, exp_year, cvc };

            // check the credit card
            const result = await checkCC(ccDict);
            results.push({
                card: number,
                status: result.status,
                response: result.response
            });
        }

        res.status(200).json({ results });
    } catch (error) {
        console.error('Error processing credit cards:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
}