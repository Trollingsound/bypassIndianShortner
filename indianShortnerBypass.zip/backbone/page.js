import { JSDOM } from 'jsdom';

const myHeaders = new Headers();
myHeaders.append("Connection", "keep-alive");
myHeaders.append("Upgrade-Insecure-Requests", "1");

export async function stepZero(url) {

    const responseToSend = []
    const errorToSend = []

    const requestOptions = {
        method: "GET",
        headers: myHeaders,
        redirect: "follow"
    };

    try {
        const response = await fetch(url, requestOptions);
        const result = await response.text();
        const dom = new JSDOM(result);
        const document = dom.window.document;
        const headers = {};

        const forms = document.querySelectorAll('form');
        const formData = [];

        forms.forEach(form => {
            const inputs = form.querySelectorAll('input, select, textarea');
            const data = {};

            inputs.forEach(input => {
                const name = input.name || input.id || `input_${formData.length}`;
                const value = input.value || input.getAttribute('value') || '';
                data[name] = value;
            });

            formData.push({
                action: form.getAttribute('action') || 'No action',
                method: form.getAttribute('method') || 'GET',
                inputs: data
            });
        });

        response.headers.forEach((value, name) => {
            headers[name] = value;
        });
        responseToSend.push({ formData: formData }, headers, result)

    } catch (error) {
        errorToSend.push(error.message)

    }

    return { responseToSend, errorToSend };
}


export async function stepOne(action, method, inputs) {

    console.log(action, method, inputs)

    const responseToSendOne = []
    const errorToSendOne = []

    const urlencoded = new URLSearchParams();
    urlencoded.append("go", inputs);

    try {
        const response = await fetch(action, {
            method: method,
            headers: {
                "Connection": "keep-alive",
                "Cache-Control": "max-age=0",
                "sec-ch-ua": `"Brave";v="129", "Not=A?Brand";v="8", "Chromium";v="129"`,
                "sec-ch-ua-mobile": 0,
                "sec-ch-ua-platform": "Windows",
                "Origin": null,
                "Content-Type": "application/x-www-form-urlencoded",
                "Upgrade-Insecure-Requests": 1,
                "User-Agent": `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36`,
                "Accept": `text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8`,
                "Sec-GPC": 1,
                "Accept-Language": `en-US,en;q=0.8`,
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Dest": "document",
                "Accept-Encoding": "gzip, deflate, br, zstd",

            },
            body: urlencoded
        })

        const result = await response.text();
        const dom = new JSDOM(result);
        const document = dom.window.document;
        const headers = {};

        console.log(result)

        const forms = document.querySelectorAll('form');
        const formData = [];

        forms.forEach(form => {
            const inputs = form.querySelectorAll('input, select, textarea');
            const data = {};

            inputs.forEach(input => {
                const name = input.name || input.id || `input_${formData.length}`;
                const value = input.value || input.getAttribute('value') || '';
                data[name] = value;
            });

            formData.push({
                action: form.getAttribute('action') || 'No action',
                method: form.getAttribute('method') || 'GET',
                inputs: data
            });
        });

        response.headers.forEach((value, name) => {
            headers[name] = value;
        });
        responseToSendOne.push({ formData: formData }, headers, result)

    } catch (error) {
        errorToSendOne.push(error.message)

    }

    if (responseToSendOne.length > 0) {
        return { responseToSendOne, errorToSendOne };
    }
}


export async function stepTwo(action, method, inputs) {

    const responseToSendTwo = [];
    const errorToSendTwo = [];

    // Prepare the form data to send
    const urlencoded = new URLSearchParams();
    urlencoded.append("humanverification", inputs.humanverification);
    urlencoded.append("newwpsafelink", inputs.newwpsafelink);

    try {
        const response = await fetch(action, {
            method: method,
            headers: {
                "Host": "paidinsurance.in",
                "Connection": "keep-alive",
                "Cache-Control": "max-age=0",
                "sec-ch-ua": `"Brave";v="129", "Not=A?Brand";v="8", "Chromium";v="129"`,
                "sec-ch-ua-mobile": "0",
                "sec-ch-ua-platform": "Windows",
                "Content-Type": "application/x-www-form-urlencoded",
                "Upgrade-Insecure-Requests": "1",
                "User-Agent": `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36`,
                "Accept": `text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8`,
                "Sec-GPC": 1,
                "Accept-Language": `en-US,en;q=0.8`,
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Dest": "document",
                "Accept-Encoding": "gzip, deflate, br, zstd",
            },
            body: urlencoded
        });

        const result = await response.text();
        const dom = new JSDOM(result);
        const document = dom.window.document;

        const headers = {};

        const link = result.split(`window.open('`)[1].split(`',`)[0]

        responseToSendTwo.push({ link: link });

        response.headers.forEach((value, name) => {
            headers[name] = value;
        });

        responseToSendTwo.push(headers, result);

    } catch (error) {
        errorToSendTwo.push(error.message);
    }

    return { responseToSendTwo, errorToSendTwo };
}


export async function stepThree(url) {

    const responseToSendThree = [];
    const errorToSendThree = [];

    try {
        const response = await fetch(url, {
            method: "GET",
            redirect: "follow"
        })
        const result = await response.text();
        const dom = new JSDOM(result);
        const document = dom.window.document;
        const headers = {};

        const forms = document.querySelectorAll('form');
        const formData = [];

        forms.forEach(form => {
            const inputs = form.querySelectorAll('input, select, textarea');
            const data = {};

            inputs.forEach(input => {
                const name = input.name || input.id || `input_${formData.length}`;
                const value = input.value || input.getAttribute('value') || '';
                data[name] = value;
            });

            formData.push({
                action: form.getAttribute('action') || 'No action',
                method: form.getAttribute('method') || 'GET',
                inputs: data
            });
        });

        response.headers.forEach((value, name) => {
            headers[name] = value;
        });

        try {

        } catch (e) { }

        responseToSendThree.push({ formData: formData }, result, headers);

    } catch (error) { errorToSendThree.push(error.message) }

    return { responseToSendThree, errorToSendThree };
}

export async function stepSix(url) {

    const responseToSendThree = [];
    const errorToSendThree = [];

    try {
        const response = await fetch(url, {
            method: "GET",
            redirect: "follow"
        })
        const result = await response.text();
        const dom = new JSDOM(result);
        const document = dom.window.document;
        const headers = {};

        const forms = document.querySelectorAll('form');
        const formData = [];

        forms.forEach(form => {
            const inputs = form.querySelectorAll('input, select, textarea');
            const data = {};

            inputs.forEach(input => {
                const name = input.name || input.id || `input_${formData.length}`;
                const value = input.value || input.getAttribute('value') || '';
                data[name] = value;
            });

            formData.push({
                action: form.getAttribute('action') || 'No action',
                method: form.getAttribute('method') || 'GET',
                inputs: data
            });
        });

        response.headers.forEach((value, name) => {
            headers[name] = value;
        });

        const cookies = []

        response.headers.forEach((value, name) => {
            headers[name] = value;

            // Check for Set-Cookie headers
            if (name.toLowerCase() === 'set-cookie') {
                cookies.push(value); // Add Set-Cookie values to the array
            }
        });


        responseToSendThree.push({ formData: formData }, cookies, headers);

    } catch (error) { errorToSendThree.push(error.message) }

    return { responseToSendThree, errorToSendThree };

}
export async function stepSeven(url, method, rawCsrfToken, ad_form_data, tokenField, tokenUnlock, csrfToken, appSession, app_visitor) {

    console.log(`-------------------------------------------\n`);
    console.log(`url: ${url}`);
    console.log(`-------------------------------------------\n`);
 
    function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    await delay(6000);

    const myHeaders = new Headers();
    myHeaders.append("Host", "indianshortner.com");
    myHeaders.append("Connection", "keep-alive");
    myHeaders.append("sec-ch-ua-platform", "\"Windows\"");
    myHeaders.append("X-Requested-With", "XMLHttpRequest");
    myHeaders.append("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36");
    myHeaders.append("Accept", "application/json,text/javascript,*/*;q=0.01");
    myHeaders.append("sec-ch-ua", "\"Brave\";v=\"129\",\"Not=A?Brand\";v=\"8\",\"Chromium\";v=\"129\"");
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8");
    myHeaders.append("sec-ch-ua-mobile", "?0");
    myHeaders.append("Sec-GPC", "1");
    myHeaders.append("Accept-Language", "en-US,en;q=0.5");
    myHeaders.append("Origin", "https://indianshortner.com");
    myHeaders.append("Sec-Fetch-Site", "same-origin");
    myHeaders.append("Sec-Fetch-Mode", "cors");
    myHeaders.append("Sec-Fetch-Dest", "empty");
    myHeaders.append("Referer", url);
    myHeaders.append("Accept-Encoding", "gzip,deflate,br,zstd");
    myHeaders.append("Cookie", `csrfToken=${csrfToken}; AppSession=${appSession}; app_visitor=${app_visitor}; ab=2`);

    console.log(`csrfToken=${csrfToken};AppSession=${appSession};app_visitor=${app_visitor};ab=2`)

    const urlencoded = new URLSearchParams();
    urlencoded.append("_method", method);
    urlencoded.append("_csrfToken", rawCsrfToken);
    urlencoded.append("ad_form_data", ad_form_data);
    urlencoded.append("_Token[fields]", tokenField);
    urlencoded.append("_Token[unlocked]", tokenUnlock);

    console.log(`Encoded Body: ${decodeURIComponent(urlencoded)}`);

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: urlencoded,
        redirect: "follow"
    };

    console.log(`Request Headers: ${JSON.stringify(myHeaders)}`);

    try {
        const response = await fetch("https://indianshortner.com/links/go", requestOptions);
        
        // Check for status code to detect if it's an error response
        if (!response.ok) {
            const errorResponse = await response.text();
            throw new Error(`Request failed with status ${response.status}: ${errorResponse}`);
        }

        const result = await response.json();
        console.log(response.headers);
        console.log(result);
        return result;

    } catch (error) {
        console.error("Error occurred during fetch:", error);

        return { error };
    }
}
